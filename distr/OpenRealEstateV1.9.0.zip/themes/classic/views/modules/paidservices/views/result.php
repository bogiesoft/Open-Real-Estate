<h1><?php echo Yii::t('module_payment','Payment');?></h1>

<p>
	<?php echo $message; ?>
</p>



