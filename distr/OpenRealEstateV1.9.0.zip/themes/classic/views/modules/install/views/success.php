<div>
    <?php echo tFile::getT('module_install', 'CMS Open Real Estate is successfully installed!'); ?>
</div>