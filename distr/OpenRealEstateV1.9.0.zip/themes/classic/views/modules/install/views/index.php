<h2 align="center">
	Select a language<br/>
	Выберите язык
</h2>
	<br/>
	<div class="span-3">&nbsp;</div>

	<div class="span-6" align="center">
		<a href="<?php echo $this->createUrl('config', array('lang' => 'ru')); ?>"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/flag_ru.png" alt="Russian / Русский / Russisch" /><br/>Russian / Русский / Russisch</a>
	</div>
    <div class="span-6" align="center">
        <a href="<?php echo $this->createUrl('config', array('lang' => 'en')); ?>"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/flag_us.png" alt="English / Английский / Englisch" /><br/>English / Английский / Englisch</a>
	</div>

	<div class="span-6" align="center">
		<a href="<?php echo $this->createUrl('config', array('lang' => 'de')); ?>"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/flag_de.png" alt="German / Немецкий / Deutsch" /><br/>German / Немецкий / Deutsch</a>
	</div>





