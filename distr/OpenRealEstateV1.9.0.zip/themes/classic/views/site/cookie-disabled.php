<div id="cookiesDisabledAlert">
	<div class="cookies-disabled-header">
		<h3><?php echo tc('Cookies are disabled'); ?></h3>
	</div>
	<div class="cookies-disabled--body">
		<?php echo tc('Please, enable cookies in your browser');?>
	</div>
</div>