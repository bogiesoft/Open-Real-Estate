<div class="clear"></div>
<div class="breadcrumbs">&nbsp;</div>
<div class="clear"></div>

<h1><?php echo CHtml::encode($messageTitle); ?></h1>

<div class="row">
    <p><?php echo CHtml::encode($messageText); ?></p>
</div>